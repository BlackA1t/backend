﻿using lab12;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

public class Context : DbContext
{
    public DbSet<User> Users { get; set; } = null!;

    public Context()
    {
        if (Database.IsSqlServer())
        {
            Database.EnsureDeleted();
            Database.EnsureCreated();
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {

        modelBuilder.Entity<User>().HasData(
                new User { Id = 1, Login = "artem", Password = "3333", Country = "Russia", City = "Moscow" },
                new User { Id = 2, Login = "liza", Password = "5959", Country = "France", City = "Paris" },
                new User { Id = 3, Login = "NeGaTiVe", Password = "1590", Country = "USA", City = "NY" }
        );

    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseNpgsql("Host=localhost;Port=7081;Database=usersdb;Username=postgres;Password=admin");
    }
}
