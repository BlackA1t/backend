﻿using Microsoft.AspNetCore.Mvc;

namespace lab12.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : Controller
    {
        [HttpGet]
        public IResult GetAllUsers()
        {
            List<User> users;

            using (Context db = new Context())
            {
                users = db.Users.ToList();
            }

            return Results.Json(users);
        }
    }
}
