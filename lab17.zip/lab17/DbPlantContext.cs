﻿using Microsoft.EntityFrameworkCore;

namespace lab17
{
    public class DbPlantContext : DbContext
    {
        public DbPlantContext(DbContextOptions<DbPlantContext> options) : base(options)
        {
        }

        public DbSet<Plant> Plants { get; set; }
    }
    }

