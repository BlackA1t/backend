using lab17;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Добавляем контекст базы данных
builder.Services.AddDbContext<DbPlantContext>(options =>
    options.UseSqlite("Data Source=plants.db")); // Или другое подключение, которое вы используете

// Настройка кэшей
builder.Services.AddDistributedMemoryCache(); // Для распределенного кэша
builder.Services.AddMemoryCache(); // Для кэша в памяти
builder.Services.AddTransient<PlantService>(); // Регистрация сервиса растений

var app = builder.Build();

// Инициализация базы данных
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<DbPlantContext>();
    db.Database.EnsureCreated(); // Создаёт базу данных, если она не существует

    // Проверяем, есть ли уже растения в базе данных
    if (!db.Plants.Any())
    {
        // Если нет, добавляем несколько растений
        db.Plants.AddRange(new List<Plant>
        {
            new Plant(1, "Rose", 10),
            new Plant(2, "Tulip", 5),
            new Plant(3, "Daisy", 8)
        });
        await db.SaveChangesAsync(); // Сохраняем изменения
    }
}

// Асинхронный маршрут для получения информации о растении по ID
app.MapGet("/plant/{id}", async (int id, PlantService plantService) =>
{
    var plant = await plantService.GetPlant(id); // Асинхронный вызов метода получения растения
    return plant != "NotFound" ? Results.Ok(plant) : Results.NotFound(); // Возвращаем результат
});

app.Run(); // Запуск приложения

