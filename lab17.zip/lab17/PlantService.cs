﻿using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace lab17
{
    public class PlantService
    {
        private readonly DbPlantContext _db;
        private readonly IMemoryCache _cache;
        private readonly IDistributedCache _redis_cache;

        // Конструктор класса, принимающий контекст базы данных и кэши
        public PlantService(DbPlantContext db, IMemoryCache cache, IDistributedCache redis)
        {
            _db = db;
            _cache = cache;
            _redis_cache = redis;
        }

        // Асинхронный метод для получения растения по ID
        public async Task<string> GetPlant(int id)
        {
            // Проверяем кэш
            if (_cache.TryGetValue(id, out Plant plant))
            {
                return plant.ToString() + " (from MemoryCache)";
            }

            // Получаем данные из базы данных асинхронно
            plant = await _db.Plants.FirstOrDefaultAsync(p => p.ID == id);
            if (plant != null)
            {
                // Устанавливаем значение в кэш
                _cache.Set(id, plant, new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMinutes(5)));
                return plant.ToString() + " (from DataBase)";
            }

            return "NotFound"; // Возвращаем "NotFound", если растение не найдено
        }
    }
}
