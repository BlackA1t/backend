﻿namespace lab6
{
    public class Student
    {
        public string Name { get; set; }
        public string University { get; set; }
    }
}
