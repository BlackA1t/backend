﻿using App.Metrics;
using App.Metrics.Counter;

namespace lab18
{
    public class AppMetrics
    {
        public static CounterOptions CounterCallGetPlant => new CounterOptions
        {
            Context = "PlantService",
            Name = "GetPlantCall",
            MeasurementUnit = Unit.Calls,
            Tags = new MetricTags(new[] {"PlantService"}, new[] {"NumberOne"})
        };
    }
}
