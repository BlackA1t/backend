﻿using Microsoft.EntityFrameworkCore;

namespace lab17
{
    public class DbPlantContext
    {
        public List<Plant> Plants = new List<Plant> { 
            new Plant(1, "Basil", 200),
            new Plant(2, "Cactus", 300),
            new Plant(3, "Aloe", 100)
        };
    }
}
