using App.Metrics;
using App.Metrics.Formatters.Prometheus;
using lab17;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddTransient<DbPlantContext>();

builder.Services.AddTransient<PlantService>();

builder.Services.AddMemoryCache();

builder.Services.AddControllers();

builder.WebHost
    .UseMetricsWebTracking(options =>
    {
        options.OAuth2TrackingEnabled = true;
    })
    .UseMetricsEndpoints(options =>
    {
        options.MetricsTextEndpointOutputFormatter = new MetricsPrometheusTextOutputFormatter();
        options.MetricsEndpointOutputFormatter = new MetricsPrometheusProtobufOutputFormatter();
    });

var app = builder.Build();

app.MapGet("/", () => "Hello!");

app.MapControllers();

app.Run();
