﻿using Microsoft.AspNetCore.Mvc;

namespace lab4
{
    [ApiController]
    public class StudentController : ControllerBase
    {
        [Route("Students")]
        [Route("Students/Get")]
        public string Get()
        {
            var list = Student.Students;
            string students = "";
            foreach (var pl in list)
            {
                students += $"{pl.Id} {pl.Name},\n";
            }
            return students;
        }

        [Route("Student/Get/{id}")]
        public string Get(int id)
        {
            foreach (var pl in Student.Students)
            {
                if (pl.Id == id)
                {
                    return $"{pl.Id} {pl.Name}";
                }
            }
            return "Student not found";
        }
    }
}
