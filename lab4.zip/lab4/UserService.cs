﻿namespace lab4
{
    public class UserService
    {
        public List<User> users = new List<User>
        {
            new User(1, "Artem"),
            new User(2, "Liza"),
            new User(3, "Marat")
        };

        public string GetById(int id)
        {
            foreach (User u in users) 
            {
                if (u.Id == id)
                    {
                        return $"Id: {u.Id}, Name: {u.Name}";
                    }
            }
            return "User not found";
        }
    }

    public class User
    {
        public User(int id, string name)
        {
            Id = id;
            Name = name;
        }
        public int Id;
        public string Name; 
    }
}
