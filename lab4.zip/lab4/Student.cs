﻿namespace lab4
{
    public class Student
    {
        public static List<Student> Students = new List<Student>
        {
            new Student("Artem"),
            new Student("Liza"),
            new Student("Marcus")
        };

        private static int ids = 0;
        public Student(string name)
        {
            ids++;
            Id = ids;
            Name = name;
        }
        public int Id {  get; set; }
        public string Name { get; set; }
    }
}
