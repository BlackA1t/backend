﻿using Microsoft.AspNetCore.Mvc;

namespace lab4
{
    [ApiController]
    public class HomeController : ControllerBase
    {
        [Route("Home/Index")]
        public string Index()
        {
            return "Index";
        }

        [Route("Home/Index/{id}")]
        public IActionResult Index(int id)
        {
            return Ok($"Home Index {id}");
        }
    }
}
