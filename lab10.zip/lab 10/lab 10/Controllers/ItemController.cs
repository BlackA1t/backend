﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

[Route("api/[controller]")]
[ApiController]
public class ItemController : ControllerBase
{
    private readonly List<Item> _items = new List<Item>()
    {
        new Item { ItemId = 1, Name = "Item 1", Price = 50.99m },
        new Item { ItemId = 2, Name = "Item 2", Price = 99.50m },
        new Item { ItemId = 3, Name = "Item 3", Price = 199.00m }
    };

    [HttpGet]
    public ActionResult<IEnumerable<Item>> GetItems()
    {
        return _items;
    }

    [HttpGet("{id}")]
    public ActionResult<Item> GetItem(int id)
    {
        var item = _items.Find(p => p.ItemId == id);
        if (item == null)
        {
            return NotFound();
        }
        return item;
    }

    [HttpPost]
    public ActionResult<Item> PostItem(Item item)
    {
        _items.Add(item);
        return CreatedAtAction(nameof(GetItem), new { id = item.ItemId }, item);
    }

    [HttpPut("{id}")]
    public IActionResult PutItem(int id, Item item)
    {
        if (id != item.ItemId)
        {
            return BadRequest();
        }
        var existingItem = _items.Find(p => p.ItemId == id);
        if (existingItem == null)
        {
            return NotFound();
        }
        existingItem.Name = item.Name;
        existingItem.Price = item.Price;
        return NoContent();
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteItem(int id)
    {
        var item = _items.Find(p => p.ItemId == id);
        if (item == null)
        {
            return NotFound();
        }
        _items.Remove(item);
        return NoContent();
    }
}
