﻿namespace lab13.Contracts
{
    public record PlantResponse(
         Guid Id,
         string Name,
         string? Description,
         decimal Price,
         string? Family,
         string? Genus);
}