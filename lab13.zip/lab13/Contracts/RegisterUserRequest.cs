﻿using System.ComponentModel.DataAnnotations;

namespace lab13.Contracts
{
    public record RegisterUserRequest(
        [Required] string UserName,
        [Required] string Email,
        [Required] string Password);
}
