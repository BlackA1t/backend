﻿using lab13.Abstractions;
using lab13.Models;
using lab13.services;

namespace lab13.DataAccessLayer
{
    public class dbUsers : IdbUsers
    {
        public static List<User> users = new List<User> {};

        public async Task<List<User>> GetUsers()
        {
            return users;
        }

        public async Task AddUser(User user)
        {
            users.Add(user);
        }

        public async Task<User> GetUserByEmail(string email)
        {
            User res = null;

            for (int i = 0; i < users.Count; i++)
            {
                if (users[i].Email == email)
                {
                    res = users[i];
                }
            }

            if(res == null)
            {
                throw new Exception("User does not exist.");
            }

            return res;
        }

      
    }
}
