﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using lab13.Models;
using lab13.DataAccessLayer;
using lab13.Abstractions;
using System;
using Microsoft.AspNetCore.Authentication;

namespace lab13.services
{
    public class UserService
    {
        private readonly IPasswordHasher _passwordHasher;
        private readonly IdbUsers _dbUsers;

        public UserService(IdbUsers dbUsers, IPasswordHasher passwordHasher)
        {
            _passwordHasher = passwordHasher;
            _dbUsers = dbUsers;
        }
        public async Task Register(string userName, string email, string password)
        {
            var passwordHash = _passwordHasher.Generate(password);

            var user = User.Create(Guid.NewGuid(), userName, passwordHash, email);

            await _dbUsers.AddUser(user);
        }

        public async Task<User> Login(string email, string password)
        {
            var user = await _dbUsers.GetUserByEmail(email);

            var result = _passwordHasher.Verify(password, user.PasswordHash);

            if(result == true)
            {
                return user;
            }
            else
            {
                throw new Exception("Faild");
            }

        }

        public async Task<List<User>> GetUsers()
        {
            var users = await _dbUsers.GetUsers();

            return users;
        }

        public async Task<User> CreateUser(string userName, string email, string password, string role)
        {
            var passwordHash = _passwordHasher.Generate(password);

            var user = User.CreateSpecify(Guid.NewGuid(), userName, passwordHash, email, role);

            await _dbUsers.AddUser(user);

            return user;
        }
    }
}
