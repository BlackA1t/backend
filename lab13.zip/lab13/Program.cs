using lab13;
using lab13.DataAccessLayer;
using lab13.services;
using lab13.Abstractions;
using Microsoft.AspNetCore.Authentication.Cookies;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddControllers();
builder.Services.AddSwaggerGen();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie();

builder.Services.AddAuthorization();

builder.Services.AddScoped<IPasswordHasher ,PasswordHasher>();
builder.Services.AddScoped<IdbUsers, dbUsers>();
builder.Services.AddScoped<UserService>();
builder.Services.AddScoped<PLantService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();
