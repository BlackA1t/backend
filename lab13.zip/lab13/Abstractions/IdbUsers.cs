﻿using lab13.Models;

namespace lab13.Abstractions
{
    public interface IdbUsers
    {
        Task AddUser(User user);
        Task<User> GetUserByEmail(string email);

        Task<List<User>> GetUsers();
    }
}