﻿using lab13.Models;

namespace lab13.Abstractions
{
    public interface IJwtProvider
    {
        string GenerateToken(User user);
    }
}