﻿using System.Security;

namespace lab13.Models
{
    public class Role
    {
        public Role(string name)
        {
            Name = name;
        }
        public string Name { get; set; }
    }
    
}
