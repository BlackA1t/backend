﻿using lab13.Contracts;
using lab13.services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace lab13.Controllers
{
    [Controller]
    [Route("[controller]")]
    public class PlantController : ControllerBase
    {
        private readonly PLantService _plantService;

        public PlantController(PLantService plantService)
        {
            _plantService = plantService;
        }

        [Authorize(Roles = "admin")]
        [HttpGet]
        public async Task<ActionResult<List<PlantResponse>>> GetPlants()
        {
            var plants = await _plantService.GetAllPlants();
            var responce = plants.Select(p => new PlantResponse(p.Id, p.Name, p.Description, p.Price, p.Family, p.Genus));
            return Ok(responce);
        }

    }
}
