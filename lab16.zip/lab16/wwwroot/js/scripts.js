let add = document.querySelector('#add');

add.addEventListener("click", function () {
    let count = document.querySelector('#count');
    let res = Number(count.textContent) + 1;

    count.textContent = res;
});
